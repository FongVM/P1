#pragma once
#define WIN32_LEAN_AND_MEAN
#include <Windows.h>
#include <iostream>
#include <stdlib.h>
#include <d3d9.h>
#include "resource.h"

class Windows
{
private:
	//	Window handle
	HWND g_hWnd;
	HINSTANCE hInstance;
	//	Window's structure
	WNDCLASS wndClass;
	D3DPRESENT_PARAMETERS d3dPP;
	IDirect3DDevice9 * d3dDevice;
public:
	Windows();
	void createWindow();
	bool createDirectX();
	void toggleScreen();
	void clearWindow();
	void color();
	bool loop();
};

